<?php
class BookModel extends Model
{
  public function getAll()
  {
    $sql = "SELECT * FROM books ORDER BY id DESC";
    return $this->dbconn->query($sql);
  }
  public function insert($title, $author, $year, $genre, $price)
  {
    $sql = "INSERT INTO books (title, author, year, genre, price)
   VALUES ('$title', '$author', '$year', '$genre', '$price')";
    $this->dbconn->query($sql);
  }
  public function getById($id)
  {
    $sql = "SELECT * FROM books WHERE id = $id";
    return $this->dbconn->query($sql);
  }
  public function update($id, $title, $author, $year, $genre, $price)
  {
    $sql = "UPDATE books SET 
     title = '$title',
     author = '$author',
     year = '$year',
     genre = '$genre',
     price = '$price'
     WHERE id = $id";
    $this->dbconn->query($sql);
  }
  public function delete($id)
  {
    $sql = "DELETE FROM books WHERE id = $id";
    $this->dbconn->query($sql);
  }
}
