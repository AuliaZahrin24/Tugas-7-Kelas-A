<?php
class Model
{
  protected $dbconn;

  public function __construct()
  {
    $dbhostname = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "mvc_crud";
    $port = "3306";
    $this->dbconn = new mysqli(
      $dbhostname,
      $dbusername,
      $dbpassword,
      $dbname,
      $port
    );
    if ($this->dbconn->connect_errno)
      die("Database connection error!");
  }
}
