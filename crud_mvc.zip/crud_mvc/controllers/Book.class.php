<?php
class Book extends Controller
{
  public function index()
  {
    $bookModel = $this->loadModel("BookModel");
    $books = $bookModel->getAll();
    $this->loadView("books", ["books" => $books]);
  }

  public function create_form()
  {
    $this->loadView("insert_book");
  }

  public function create_process()
  {
    $title = addslashes($_POST["title"]);
    $author = addslashes($_POST["author"]);
    $year = addslashes($_POST["year"]);
    $genre = addslashes($_POST["genre"]);
    $price = addslashes($_POST["price"]);
    $bookModel = $this->loadModel("BookModel");
    $bookModel->insert($title, $author, $year, $genre, $price);
    header("location:?c=Book");
  }

  public function edit_form()
  {
    $id = $_GET["id"];
    if (!$id) header("location?c=Book");
    $bookModel = $this->loadModel("BookModel");
    $book = $bookModel->getById($id);
    if (!$book->num_rows) header("location:?c=Book");
    $this->loadView(
      "edit_book",
      ["book" => $book->fetch_object()]
    );
  }

  public function edit_process()
  {
    $id = $_POST["id"];
    $title = addslashes($_POST["title"]);
    $author = addslashes($_POST["author"]);
    $year = addslashes($_POST["year"]);
    $genre = addslashes($_POST["genre"]);
    $price = addslashes($_POST["price"]);
    $bookModel = $this->loadModel("BookModel");
    $bookModel->update($id, $title, $author, $year, $genre, $price);
    header("location:?c=Book");
  }

  public function delete_process()
  {
    $id = $_GET["id"];
    $bookModel = $this->loadModel("BookModel");
    $bookModel->delete($id);
    header("location:?c=Book");
  }
}
