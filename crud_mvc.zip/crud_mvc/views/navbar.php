<nav class='navbar'>
  <div class='navbar-container'>
    <a href='#' class='navbar-logo'>Book Store</a>
    <ul class='navbar-links'>
      <li><a href='/' class='navbar-link'>Home</a></li>
      <li><a href='/?c=Book' class='navbar-link'>Books</a></li>
      <li><a href='/?c=Book&m=create_form' class='navbar-link'>Add Data</a></li>
    </ul>
  </div>
</nav>