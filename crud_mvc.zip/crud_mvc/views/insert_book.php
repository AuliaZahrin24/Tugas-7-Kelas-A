<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Book</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>

<body>
  <?php include_once 'navbar.php'; ?>
  <div class="main">
    <form action="?c=Book&m=create_process" method="POST" class="book-form">
      <h3>Add New Book</h3>
      <label for="title">Title:</label>
      <input type="text" id="title" name="title" required autofocus placeholder="Enter book title">
      <label for="author">Author:</label>
      <input type="text" id="author" name="author" required placeholder="Enter author's name">
      <label for="year">Year of Publication:</label>
      <input type="number" id="year" name="year" required placeholder="Enter year of publication" min="1900" max="2100">
      <label for="genre">Genre:</label>
      <input type="text" id="genre" name="genre" required placeholder="Enter genre">
      <label for="price">Price:</label>
      <input type="number" id="price" name="price" required placeholder="Enter price" step="0.01">
      <input type="submit" value="Create Book" class="submit-button">
    </form>
  </div>
</body>

</html>