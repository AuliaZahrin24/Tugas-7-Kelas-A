<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book List</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
  <?php include_once 'navbar.php'; ?>
  <div class="main">
    <h2 class='page-title'>Book List</h2>
    <?php
    if (!$books) {
      echo "<p>Table does not exist.</p>";
    } else {
      if (!$books->num_rows) {
        echo "<p>No books available.</p>";
      } else {
        echo "<div class='book-list'>";
        while ($book = $books->fetch_object()) {
          echo "<div class='book-item'>";
          echo "<h3 class='book-title'>$book->title</h3>";
          echo "<p class='book-author'><strong>Author:</strong> $book->author</p>";
          echo "<p class='book-year'><strong>Year:</strong> $book->year</p>";
          echo "<p class='book-genre'><strong>Genre:</strong> $book->genre</p>";
          echo "<p class='book-price'><strong>Price:</strong> Rp. $book->price</p>";
          echo "<div class='book-actions'>
                  <a href='?c=Book&m=edit_form&id=$book->id' class='edit-button'>Edit</a>
                  <a href='?c=Book&m=delete_process&id=$book->id' class='delete-button'>Delete</a>
                </div>";
          echo "</div>";
        }
        echo "</div>";
      }
    }
    ?>
  </div>
</body>

</html>