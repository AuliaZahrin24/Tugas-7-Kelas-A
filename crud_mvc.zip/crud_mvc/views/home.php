<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Book</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>

<body>
  <?php include_once 'navbar.php'; ?>
  <div class="main">
    <h2>Selamat Datang Di Aplikasi BookStore!</h2>
  </div>
</body>

</html>